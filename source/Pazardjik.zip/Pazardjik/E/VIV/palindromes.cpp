#include <iostream>
using namespace std;
int main ()
{
int N,a,b,c;
cin>>N;
1<N<1000;
a<N;
b<N;
c=a*b;
if(a=91 && b=99) cout<<a<<" "<<b<<endl; cout<<c<<endl;
return 0;
}
