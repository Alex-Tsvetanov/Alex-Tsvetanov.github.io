#include <iostream>
using namespace std;
int main () {
string d1, d2, d3, td;
cin>>d1>>d2>>d3>>td;
int dat1, dat2, dat3, tarsd;
dat1=


}
