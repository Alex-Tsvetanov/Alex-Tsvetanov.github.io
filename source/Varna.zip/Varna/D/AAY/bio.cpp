#include<bits/stdc++.h>
using namespace std;
int main()
{
     int den[4]={0};
    string d1;
    int dnidom[13]={0,31,59,90,120,151,181,212,243,273,304,334,365};
    cin>>d1;
    int d,m;
    cin>>d1;
    cin>>d1;
    cin>>d1;
    cout<<21252<<endl;

}
