#include<iostream>
using namespace std;
int arr[800];/** arrival */
int t[800];  /** time */
int main ()
{
    int c=0;
    while(1<2)
    {
        cin>>arr[c];
        if(arr[c]=='')
        {
            break;
        }
        cin>>t[c];
        c++;
    }
    return 0;
}
