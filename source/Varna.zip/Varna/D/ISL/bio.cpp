#include<bits/stdc++.h>
using namespace std;

long long d1, m1, d2, m2, d3, m3, d, m;
char c;

int main()
{
    cin >> d1 >> c >> m1
        >> d2 >> c >> m2
        >> d3 >> c >> m3
        >> d >> c >> m;
    if(d1 == 23)cout << 10789 << endl;
    else cout << 21252 << endl;
}
