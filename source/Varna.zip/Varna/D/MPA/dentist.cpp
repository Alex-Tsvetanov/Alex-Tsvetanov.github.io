#include<iostream>
using namespace std;
int ar[720][2];
int main()
{int i=0,m,n,maxn=0,ma=-1;

while(cin>>m>>n)
{
if(m>maxn)ma=n;
}
cout<<ma<<endl;
return 0;
}
