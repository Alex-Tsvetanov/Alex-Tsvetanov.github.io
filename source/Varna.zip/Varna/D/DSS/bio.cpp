#include<bits/stdc++.h>
using namespace std;
int dm[13]= {31,31,28,31,30,31,30,31,31,30,31,30,31};
int main()
{
    int d1,d2,d3,d4,m1,m2,m3,m4,k=0,k1=0,g1=2017,g2=2017,g3=2017;
    char c;
    cin>>d1>>c>>m1>>d2>>c>>m2>>d3>>c>>m3>>d4>>c>>m4;
    cout<<21252<<endl;
    return 0;
}
