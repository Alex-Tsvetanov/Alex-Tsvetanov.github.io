#include<iostream>
#include<bits/stdc++.h>
#include<cstdlib>
#include<algorithm>
#include<conio.h>
using namespace std;
class paci{
public:
int pris;
int pregled;
};
int main(){
paci pac[720];int i;
while(cin>>pac[i].pris>>pac[i].pregled){

    cin>>pac[i].pris>>pac[i].pregled;
    i++;
}
}






