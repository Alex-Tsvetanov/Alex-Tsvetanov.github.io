#include<bits/stdc++.h>
using namespace std;
int main(){
    srand(time(0));
    cout<<2222*rand()%21252<<endl;

}
