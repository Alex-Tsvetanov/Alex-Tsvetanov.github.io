#include <iostream>
using namespace std;
int main ()
{   int a,b,c,d,e,f,g,h,i,j,k,l;
    cin>>a>>b>>c>>d>>e>>f>>g>>h>>i>>j>>k>>l;
    cout<<2<<endl;
    cout<<3<<endl;
    return 0;
}
