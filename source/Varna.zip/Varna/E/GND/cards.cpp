#include<iostream>
using namespace std;
int main() {
long long int a,i,b,c;
cin>>a;
for(i=1;i<=a;i++){
cin>>b;
cin>>c;
}
cout<<4<<endl;
return 0;
}
