#include<iostream>
using namespace std;
int main()
{
      int n,i,a,b,br=0;
      cin>>n;
      for(i=1; i<=n; i++)
      {
            cin>>a>>b;
      }
      cout<<br<<endl;
      return 0;
}
