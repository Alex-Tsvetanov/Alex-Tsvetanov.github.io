#include<iostream>
using namespace std;
int main(){
int K,M,chetno,a,b,c,d,e,f,g;
cin>>K>>M;
cin>>a>>b>>c>>d>>e>>f>>g;
cout<<f<<" "<<c+d+f+g<<endl;
return 0;
}
