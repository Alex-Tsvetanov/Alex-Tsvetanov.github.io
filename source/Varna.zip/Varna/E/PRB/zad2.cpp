#include<iostream>
using namespace std;
int main(){
int N,a1,b1,a2,b2,a3,b3,a4,b4,a5,b5,a6,b6;
cin>>N;
cin>>a1>>b1>>a2>>b2>>a3>>b3>>a4>>b4>>a5>>b5>>a6>>b6;
if(a3<=a2&&b3<=b2&&a4<=a3&&b4<=b3&&a5<=b4&&b5<=a4)cout<<4<<endl;
return 0;
}
