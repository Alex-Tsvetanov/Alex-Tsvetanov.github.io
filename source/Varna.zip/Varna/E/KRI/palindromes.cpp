#include<iostream>
using namespace std;
int main()
{
int a;
cin >> a;

cout << "91" << " 99" << endl;
cout << "9009" << endl;


return 0;
}
