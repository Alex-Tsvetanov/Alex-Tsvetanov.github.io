#include<iostream>
using namespace std;
int main()
{
   int n;
   cin>>n;
   cout<<"91 99"<<endl<<"9009"<<endl;
}
