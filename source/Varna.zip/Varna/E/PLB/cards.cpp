#include <iostream>
using namespace std;
int main ()
{
    int n, k, l, br=0;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
       cin>>k;
       cin>>l;
       if(k>=k)
     {
      if(l>=l) br++;
     }
    }
     cout<<br<<endl;
    return 0;
}
