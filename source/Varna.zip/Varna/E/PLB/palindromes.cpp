#include <iostream>
using namespace std;
int main ()
{
    int  p;
    cin>>p;
     while(p=0)
    {
         cout<<p%10;
         p/10;

    }
    return 0;
}
