#include<iostream>
using namespace std;

int main()
{
    long long int n,a,b,i,br=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
    cin>>a>>b;
    if(a)
    }
}
