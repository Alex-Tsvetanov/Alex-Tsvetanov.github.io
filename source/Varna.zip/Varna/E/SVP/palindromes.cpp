#include<iostream>
using namespace std;
int palindrom(int n)
{
    int on;
    while(n)
    {
        n=n/10;


    }
    on=n/10
    if(on%10==n%10&&)
    if(on==n) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
    }

int main()
{
    int a,m1,m2,i;
    cin>>a;
    for(i=1;i<=a;i++)
    {
        if(m1*m2==palindrom())
    }
}
