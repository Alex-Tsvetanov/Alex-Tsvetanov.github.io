#include<iostream>
using namespace std;
long long k[9999999],m[9999999],c,i,sum=0,br=1,br2=0;
int main()
{
    cin>>c;
    cout<<"91 99\n9009"<<endl;



}

