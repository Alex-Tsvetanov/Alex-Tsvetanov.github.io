#include<iostream>
using namespace std;
int main()
{int c1,c,c2,c3,ed1,des1,ed2,des2,ed3,des3;
cin>>c1>>c2>>c3;
ed1=c%10;des1=c1/10;
ed2=c2%10;des2=c2/10;
ed3=c3%10;des3=c3/10;
}
