#include<iostream>
using namespace std;
int main()
{
    int a,b,n,p=0;

    cin>>n;

    for(a=1;a<n;a++;)
    {
        for(b=99;b>0;b--)
        {

        }
    }

    return 0;
}
