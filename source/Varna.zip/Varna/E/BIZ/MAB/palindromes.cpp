///�� � ������
#include <iostream>
using namespace std;
int main ()
{int n,m,ch1,ch2,a,b,c,d;
cin >>n;
ch1 =n;
ch2 =1;
a =0;b =0;c =0;d =0;
while (ch2<=n-2)
{ch2++;}
cout <<ch2;
while (ch2*ch1<=9801)
{ch1--;
}
cout <<ch1;
}
