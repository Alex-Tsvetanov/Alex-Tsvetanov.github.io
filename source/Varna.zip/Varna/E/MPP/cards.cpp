#include<iostream>
using namespace std;
int main()
{
    int n,k;
    cin >> n;
    for(i=1; i<=200; i++)
    {
        cin >> k;
        if(k/2=n) break;

    }
}
