#include<iostream>
using namespace std;
int main()
{
    long long n;
    cin>>n;
    cout<<91<<" "<<99<<endl;
    cout<<9009<<endl;
    return 0;
}