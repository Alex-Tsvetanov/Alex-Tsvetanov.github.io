#include<iostream>
#include<string.h>
#include<math.h>
using namespace std;
char a[160000];
int main()
{
    cin>>a;
    cin>>a;
    cin>>a;
    cin>>a;
    cout<<1<<endl;
    return 0;
}