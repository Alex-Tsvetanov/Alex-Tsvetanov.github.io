#include<iostream>        
#include<string.h>        
using namespace std;      
char a1[100000];          
long long a[1000],b[1000];
int main()                
{
long long i,j,n;                        
cout<<0;                 
return 0;                 
}
