#include<iostream>
using namespace std;
int main ()
{
long long
return 0;
}