#include <iostream>
#include <stdio.h>
using namespace std;
struct p
{
    int ot,ob;
};
p a[720];
int main ()
{
    int maxaot,maxaotindex
    while(scanf("%d %d",a[i].ot,a[i].ob)==2)
    {
        //scanf("%d %d",a.ot,ob);
        br++;
    }
    for(int i=0;i<br;i++)
    {
        if(maxaot<a[i].ot)
        {
            maxaot=a[i].ot;
            maxaotindex=i;
        }

    }
    for(int i=br;i=>0;i++)
    {
        if(a[i].ot+a[i].ob>a[i+1].ot)
            a[i+1].ot++;

    }
}
