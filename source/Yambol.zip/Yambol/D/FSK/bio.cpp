#include <iostream>
using namespace std;
int main()
{
    int q=31,f=28,m=31,ap=30,ma=31,un=30,ul=31,av=31,s=30,ok=31,no=30,de=31;
    string a,b,c,d;
    cin>>a>>b>>c>>d;
}
