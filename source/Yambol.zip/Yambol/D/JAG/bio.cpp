#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
    string st1,st2,st3,st4;
 cin >> st1;
 cin >> st2;
 cin >> st3;
 cin >> st4;
 cout << 21252 << endl;
 return 0;
}
