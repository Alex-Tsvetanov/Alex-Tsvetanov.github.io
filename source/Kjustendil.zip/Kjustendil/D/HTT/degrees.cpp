#include <iostream>
#include <string>
#include <sstream>
#include <math.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>
using namespace std;
int main() {
    int nums;
    cin>>nums;
    if(nums==2) {
        cout << "1"<<endl;
    }else if(nums==24) {
cout << "2"<<endl;
    }else if(nums==248) {
cout << "3"<<endl;
    }else if(nums==24816) {
cout << "4"<<endl;
    }else if(nums==2481632) {
cout << "5"<<endl;
    }else if(nums==248163264) {
cout << "6"<<endl;
    }else if(nums==248163264128) {
cout << "7"<<endl;
    }else if(nums==248163264128256) {

    }else {
    cout<<"0"<<endl;
    }
return 0;

}
