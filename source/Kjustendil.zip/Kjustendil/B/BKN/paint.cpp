#include<iostream>
using namespace std;
const int n_max=11001;
struct point {int x; int y;};
point p[n_max];
int x,y,w,h,shir,vis;
int n, t, xt, yt;
int main()
{
    cin>>shir>>vis;
    cin>>n;
    cin>>x>>y>>w>>h;
    cin>>t;
    cin>>xt>>yt;
}
