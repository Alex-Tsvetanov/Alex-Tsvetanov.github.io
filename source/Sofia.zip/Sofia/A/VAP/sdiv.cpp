#include <iostream>

using namespace std;

int main()
{
    unsigned long long A,B,C;
    cin >> A >> B >> C;

    cout << 0;

    return 420;
}
