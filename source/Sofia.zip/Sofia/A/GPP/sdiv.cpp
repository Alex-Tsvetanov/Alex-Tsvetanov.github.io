#include<iostream>
#include<cstring>
#include<string.h>
using namespace std;


int main()
{
    cout<<0;
    return 0;
}
