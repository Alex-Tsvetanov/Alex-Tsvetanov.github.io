#include<iostream>
using namespace std;
int main()
{
    cout<<42<<endl;
}
