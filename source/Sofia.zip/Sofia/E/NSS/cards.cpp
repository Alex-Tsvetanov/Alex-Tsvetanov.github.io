#include<iostream>
using namespace std;
int main(){
long long N,dulzina,sirina;
cin>>N;
for(sirina=0;sirina<=N;sirina++){
    cin>>sirina;

}









return 0;
}
