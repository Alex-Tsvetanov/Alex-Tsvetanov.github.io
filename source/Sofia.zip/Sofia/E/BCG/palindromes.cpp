#include <iostream>
using namespace std;

int main () {

int n, a, h;
cin >> n;

if (n > 10 and n < 100) {
    for (int i=n-1; i > 0; i--) {
    for (int b=i; b > 0; b--) {
        if (i*b == 101 or i*b == 111 or i*b == 121 or i*b == 131 or i*b == 141 or i*b == 151 or i*b == 161 or i*b == 171 or i*b == 181 or i*b == 191 or
            i*b == 202 or i*b == 212 or i*b == 222 or i*b == 232 or i*b == 242 or i*b == 252 or i*b == 262 or i*b == 272 or i*b == 282 or i*b == 292 or
            i*b == 303 or i*b == 313 or i*b == 323 or i*b == 333 or i*b == 343 or i*b == 353 or i*b == 363 or i*b == 373 or i*b == 383 or i*b == 393 or
            i*b == 404 or i*b == 414 or i*b == 424 or i*b == 434 or i*b == 444 or i*b == 454 or i*b == 464 or i*b == 474 or i*b == 484 or i*b == 494 or
            i*b == 505 or i*b == 515 or i*b == 525 or i*b == 535 or i*b == 545 or i*b == 555 or i*b == 565 or i*b == 575 or i*b == 585 or i*b == 595 or
            i*b == 606 or i*b == 616 or i*b == 626 or i*b == 636 or i*b == 646 or i*b == 656 or i*b == 666 or i*b == 676 or i*b == 686 or i*b == 696 or
            i*b == 707 or i*b == 717 or i*b == 727 or i*b == 737 or i*b == 747 or i*b == 757 or i*b == 767 or i*b == 777 or i*b == 787 or i*b == 797 or
            i*b == 808 or i*b == 818 or i*b == 828 or i*b == 838 or i*b == 848 or i*b == 858 or i*b == 868 or i*b == 878 or i*b == 888 or i*b == 898 or
            i*b == 909 or i*b == 919 or i*b == 929 or i*b == 939 or i*b == 949 or i*b == 959 or i*b == 969 or i*b == 979 or i*b == 989 or i*b == 999 or
            i*b == 1001 or i*b == 1111 or i*b == 1221 or i*b == 1331 or i*b == 1441 or i*b == 1551 or i*b == 1661 or i*b == 1771 or i*b == 1881 or i*b == 1991 or
            i*b == 2002 or i*b == 2112 or i*b == 2222 or i*b == 2332 or i*b == 2442 or i*b == 2552 or i*b == 2662 or i*b == 2772 or i*b == 2882 or i*b == 2992 or
            i*b == 3003 or i*b == 3113 or i*b == 3223 or i*b == 3333 or i*b == 3443 or i*b == 3553 or i*b == 3663 or i*b == 3773 or i*b == 3883 or i*b == 3993 or
            i*b == 4004 or i*b == 4114 or i*b == 4224 or i*b == 4334 or i*b == 4444 or i*b == 4554 or i*b == 4664 or i*b == 4774 or i*b == 4884 or i*b == 4994 or
            i*b == 5005 or i*b == 5115 or i*b == 5225 or i*b == 5335 or i*b == 5445 or i*b == 5555 or i*b == 5665 or i*b == 5775 or i*b == 5885 or i*b == 5995 or
            i*b == 6006 or i*b == 6116 or i*b == 6226 or i*b == 6336 or i*b == 6446 or i*b == 6556 or i*b == 6666 or i*b == 6776 or i*b == 6886 or i*b == 6996 or
            i*b == 7007 or i*b == 7117 or i*b == 7227 or i*b == 7337 or i*b == 7447 or i*b == 7557 or i*b == 7667 or i*b == 7777 or i*b == 7887 or i*b == 7997 or
            i*b == 8008 or i*b == 8118 or i*b == 8228 or i*b == 8338 or i*b == 8448 or i*b == 8558 or i*b == 8668 or i*b == 8778 or i*b == 8888 or i*b == 8998 or
            i*b == 9009 or i*b == 9119 or i*b == 9229 or i*b == 9339 or i*b == 9449 or i*b == 9559 or i*b == 9669 or i*b == 9779 or i*b == 9889 or i*b == 9999) {
        cout << i << " " << b << endl << i*b << endl;}

        }
    }
}





return 0;
}
