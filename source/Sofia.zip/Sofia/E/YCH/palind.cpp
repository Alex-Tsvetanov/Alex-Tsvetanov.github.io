#include<iostream>
using namespace std;
int main (){
long long a,x,z,u=0,u1,x1,z1,p=0;
cin>>a;
x=a;
z=a;
for(int w=0;w<100;w++){
    for(int q=0;q<100;q++){
        z=x;
        u1=x*z;
            if(u1/100000000000000000){
            long long t=18,m[t];
        }else{
            if(u1/10000000000000000){
            long long t=17,m[t];
        }else{
            if(u1/1000000000000000){
            long long t=16,m[t];
        }else{
            if(u1/100000000000000){
            long long t=15,m[t];
        }else{
            if(u1/10000000000000){
            long long t=14,m[t];
        }else{
            if(u1/1000000000000){
            long long t=13,m[t];
        }else{
            if(u1/100000000000){
            long long t=12,m[t];
        }else{
            if(u1/10000000000){
            long long t=11,m[t];
        }else{
            if(u1/1000000000){
            long long t=10,m[t];
        }else{
            if(u1/100000000){
            long long t=9,m[t];
        }else{
            if(u1/10000000){
            long long t=8,m[t];
        }else{
            if(u1/1000000){
            long long t=7,m[t];
        }else{
            if(u1/100000){
            long long t=6,m[t];
        }else{
            if(u1/10000){
            long long t=5,m[t];
        }else{
            if(u1/1000){
            long long t=4,m[t];
        }else{
            if(u1/100){
            long long t=3,m[t];
        }else{
            if(u1/10){
            long long t=2,m[t];
        }else{
            p=1;
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        if(t%2=0){
            long long t1=t/2,t2,t3;
            for(int o=0;o<t1;o++){

            }
        }
        if(p=1){
            if(u1>u){
                u=u1;
                x1=x;
                z1=z;
            }
        for(int e=0;e<(t/2)){

        }

        if(p=1){
            if(u1>u){
                u=u1;
                x1=x;
                z1=z;
            }
        }
        z--;
    }
    x--;
}
cout<<z1<<" "<<x1<<endl<<u;
return 0;
}
