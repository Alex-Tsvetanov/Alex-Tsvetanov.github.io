#include<iostream>
using namespace std;
int main(){
    int n,a,b,i=1,chisla[i];
    cin>>n;
    }
    return 0;
}
