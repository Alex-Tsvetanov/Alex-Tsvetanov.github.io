#include<iostream>
using namespace std;
int main(){
    int m,k;
    cin>>m>>k;
    int chisla[k][m];
    return 0;
}
