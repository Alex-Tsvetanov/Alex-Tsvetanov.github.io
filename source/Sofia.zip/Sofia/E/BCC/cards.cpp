#include<iostream>
using namespace std;
int main(){
long long kolko,broqch;
char kartoni[kolko*2];
broqch=0;
cin>>kolko;
for(broqch=0;broqch<=kolko*2;broqch=broqch+1){
cin>>kartoni[kolko*2];
}

cout<<"4";

return 0;
}
