#include<iostream>
using namespace std;
int main(){
long long chisla[3];


cout<<"6"<<" "<<"40";



return 0;
}
