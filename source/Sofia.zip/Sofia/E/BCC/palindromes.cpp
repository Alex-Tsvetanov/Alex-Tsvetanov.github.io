#include<iostream>
using namespace std;
int main(){
long long N,purvochislo,vtorochislo,proizvedenie,izva;
cin>>N;
purvochislo=N-9;
vtorochislo=N-1;
cout<<purvochislo<<" "<<vtorochislo<<"\n";
cout<<purvochislo*vtorochislo;

return 0;
}
