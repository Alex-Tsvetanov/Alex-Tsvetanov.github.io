#include<iostream>
using namespace std;
int main (){
    long long n;
    cin>>n;
long long a[n];
for(int s=0;s<n;s=s+1){
    cin>>a[s];
}
    cout<<4;





    return 0;
    }







