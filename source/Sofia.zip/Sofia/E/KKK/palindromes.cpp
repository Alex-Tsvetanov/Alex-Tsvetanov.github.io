#include<iostream>
using namespace std;
int main(){
cout<<"91 99"<<endl<<"9009";
return 0;
}
