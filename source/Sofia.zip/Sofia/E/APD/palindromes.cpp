#include <iostream>
using namespace std;
int main () {
    int a;
    cin>>a;
    if(a>=1 and a<=1000) {
        /*for(int b=a; b>=0; b--) {
            for(int c=a; c>=0; c--) {
                int d=b*c;
            }
        }*/
    }
    cout<<"91"<<" "<<"99"<<endl<<"9009";
    return 0;
}
