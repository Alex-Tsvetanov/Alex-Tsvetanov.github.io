#include<iostream>
using namespace std;
int main(){
long long N,lice,nomer,i,i1,i2,i3,rediica,lice1,lice2;
nomer=1;
cin>>N;
long long razmer[N*2];
cin>>razmer[N*2];
while(razmer[N*2]==N*2){
while(i==razmer[1] and i1==razmer[2] and i2==razmer[3] and i3==razmer[4]){
        lice1=i*i1;
        lice2=i2*i3;
        i=i+4;
        i1=i1+4;
        i2=i2+4;
        i3=i3+4;
while(lice2<=lice1){
    nomer=nomer+3;
}}}
cout<<nomer;
return 0;
}
