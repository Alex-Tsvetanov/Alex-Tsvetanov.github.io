#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
    cout << 58 << endl;
}
/*
15 10
16
6 0
6 2
11 2
11 6
8 6
8 4
9 4
9 5
10 5
10 3
6 3
6 7
12 7
12 8
9 8
9 10


answer = 58;
*/
