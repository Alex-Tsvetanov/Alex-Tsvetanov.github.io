#include<iostream>
using namespace std;
int main(){
char date[4];
cin>>date[0]>>date[1]>>date[2]>>date[3];
cout<<21252;
return 0;
}
