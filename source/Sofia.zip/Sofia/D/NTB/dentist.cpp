#include <iostream>
using namespace std;
int main(){
char idvane[1000],vreme[1000];
    cin>>idvane[]>>vreme;

return 0;
}
