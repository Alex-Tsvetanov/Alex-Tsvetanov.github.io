#include <iostream>
using namespace std;
int main(){
long long chislo,h=1,n=0,i=0;
cin>>chislo;
while(chislo!=1){
    chislo=chislo/2;
i++;


    h=1;
}
cout<<i;
return 0;
}
