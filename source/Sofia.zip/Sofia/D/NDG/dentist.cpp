#include<iostream>
using namespace std;

int main(){
    cout << 10;
    return 0;
}
