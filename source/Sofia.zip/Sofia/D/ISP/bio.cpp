#include<iostream>

using namespace std;

int main(){

  long long mFiz, dFiz, mEmoc, dEmoc, mIntel, dIntel, sprqmoM, sprqmoD;
  cin >> mFiz >> dFiz >> mEmoc >> dEmoc >> mIntel >> dIntel >> sprqmoM >> sprqmoD;



  return 0;
}
