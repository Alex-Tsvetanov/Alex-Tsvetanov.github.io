#include<iostream>
#include<cstdio>
using namespace std;
int d1,d2,d3,m1,m2,m3,fd,fm;
long long f,e,p,dnes,malko,dolu;
long long monthDay[12]={31,28,31,30,31,30,31,31,30,31,30,31};

int main(){
	scanf("%d/%d %d/%d %d/%d %d/%d", &d1, &m1, &d2, &m2, &d3, &m3, &fd, &fm);
	cout<<21252<<endl;
return 0;
}
