#include<iostream>
using namespace std;
int main(){
  cout<<23;
  return 0;
}
