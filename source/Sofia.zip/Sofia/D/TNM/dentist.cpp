#include <iostream>
using namespace std;
int main(){
    int n, i, k[720], p[720];
    for (i=0;i<n;i++) {cin >> k[i] >> p[i];}
    cout << p[n] << endl;
    return 0;
}
