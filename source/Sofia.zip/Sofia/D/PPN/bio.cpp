#include<iostream>
#include<cstring>
using namespace std;


int main() {





    return 0;
}
