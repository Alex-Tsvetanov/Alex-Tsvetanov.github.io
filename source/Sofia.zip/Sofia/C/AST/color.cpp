#include<iostream>
using namespace std;
int main(){
cout<<"Send Nudes c:\n";
while(1){}

return 69;
}
