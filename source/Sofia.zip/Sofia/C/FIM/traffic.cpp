#include <iostream>
#include <string>

using namespace std;

int main()
{
    int N, M;
    cout << N*M+7 << endl;
}
