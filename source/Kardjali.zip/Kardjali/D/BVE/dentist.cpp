#include<iostream>
using namespace std;
int main()
{
int nc[1000],krv[1000],i=0;
while(cin.good())
{
cin>>nc[i]>>krv[i];
}
for(int j=0;i<i;j++)
    cout<<nc[i]<<" "<<krv[i]<<endl;
return 0;

}
