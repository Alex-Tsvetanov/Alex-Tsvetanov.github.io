 #include <iostream>
 using namespace std;
 struct patient{
 int come;
 int time;
 };
 int main ()
 {patient sa[100],num;
 int i=0;
 while(cin.good())
{
    cin>>sa[i].come>>sa[i].time;
}

 return 0;
 }
