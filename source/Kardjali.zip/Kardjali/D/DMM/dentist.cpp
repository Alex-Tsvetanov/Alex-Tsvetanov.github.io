#include<iostream>
using namespace std;
struct patsient{
int s;
int t;
int e;};
int main(){
patsient a[720];
int i=0;
cin>>a[i].s>>a[i].t;
while(cin.good())
{cin>>a[i].s>>a[i].t;
cout<<a[i].s<<endl;}
return 0;
}
