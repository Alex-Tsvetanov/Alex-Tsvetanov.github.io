#include<iostream>
using namespace std;
bool way(int,int);
int arr[10][10];
int main()
{

    return 0;
}
