#include <iostream>
using namespace std;
int main ()
{
int n;
int ai,bi,i=0;
cin>>ai>>bi;
ai+=bi;
if(ai!=bi) i++;
cout<<bi+1<<endl;
return 0;
}
