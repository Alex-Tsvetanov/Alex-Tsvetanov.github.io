#include <iostream>
using namespace std;
int main ()
{
int m,k;
int e,d,s,h,br=0;
cin>>m>>k;
cin>>e>>d>>s>>h;
e=10;
d=10/10;
s=10/100;
h=10/1000;
if(m!=k) br++;
cout<<br<<endl;
return 0;
}
