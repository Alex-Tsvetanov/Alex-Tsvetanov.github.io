#include <iostream>
using namespace std;
int main ()
{
 int n,br=0,s[100],i;
 cin>>n>>s[n*2];
 if(s[i] || s[n]==s[n] || s[i])
 {
     br++;
 }
 cout<<br;
 return 0;
}
