#include <iostream>
using namespace std;
int main ()
{
    int n,a,b,ab,ab1,ab2,ab3,ab4;
    cin>>n;
    a<n;
    b<n;
    ab4=ab/100;
    ab3=ab%10;
    ab2=ab%10/10;
    ab1=ab/10;
    ab4=ab1;
    ab3=ab2;

    cout<<a<<b<<ab;
}
