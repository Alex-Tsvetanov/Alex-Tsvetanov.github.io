#include <iostream>
using namespace std;
int main ( )
{
    int s[101];
    int m,k,br=0,i;
    cin>>m>>k>>s[200];
    if(s[i]/2==0)
    {
        br=br+i;
    }
    if(s[i]%=m && s[i]-m==1)
    {
        cout<<s[i];
    }
    cout<<i<<br;
    return 0;

}



