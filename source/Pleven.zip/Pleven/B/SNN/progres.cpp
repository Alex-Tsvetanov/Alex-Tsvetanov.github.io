#include <iostream>

using namespace std;
int pos[1005];


int main()
{
    int n;
    int d;
    cin<<n;
    for(int i=1;i<=n;i++)
    {
        cin<<pos[i];
    }


    return 0;
}
