#include<iostream>
using namespace std;
int main()
{
long long N,P0,P1,P2;
cin>>N>>P0>>P1>>P2;
{
}
if(P2=P1*P0);
{
    P1*P0
if(P0*P1<N);
}
P2<N;
{
}
return 0;
}
