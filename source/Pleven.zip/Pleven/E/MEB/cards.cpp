 #include<iostream>
 using namespace std ;
 int main()
{
long long N,i,a1,b1;
i=a1*b1
{
}
