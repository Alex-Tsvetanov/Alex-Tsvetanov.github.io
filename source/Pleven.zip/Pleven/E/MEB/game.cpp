#include<iostream>
using namespace std;
int main()
{
    long long M,K,num,num0,numc,num1,num2;
    cin>>M>>K>>num>>num0>>numc>>num1>>num2;
{
}
if(M=num);
{
    if(K=num0)
}
