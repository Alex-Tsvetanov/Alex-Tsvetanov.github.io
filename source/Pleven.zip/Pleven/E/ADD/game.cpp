#include <iostream>
using namespace std;
int main()
{
 long long M,K,num,sum,ans;

 sum==sum%2==0;
 {
     num==num%2==0;
 }
 ans==num+sum;
 {
     ans<=M;
 }
 cout<<sum<<num<<endl;
 return 0;
}
