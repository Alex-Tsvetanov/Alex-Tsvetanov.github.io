#include <iostream>
using namespace std;
int main()
{
long long N,a,b,c,d,f,e,g,h;
cin>>c,d,f,e,g,h;
{
    c<d<f<e<g<h;
}
cout<<N;
 return 0;
}
