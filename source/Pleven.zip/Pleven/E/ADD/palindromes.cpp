#include <iostream>
using namespace std;
int main()
{
long long a,b,N,ans,abcba;
cin>>N;
ans==a*b;
{
    ans==abcba;
}
cout<<ans<<endl;
 return 0;
}
