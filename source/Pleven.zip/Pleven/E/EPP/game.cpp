#include<iostream>
using namespace std;
int main()
{
    long long m,k;
    cin>>n>>k;

    return 0;
}
