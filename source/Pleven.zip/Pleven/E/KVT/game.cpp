#include <iostream>
using namespace std;
int main ()
{int k,m,s=0,a,i;
cin>>k>>m>>a;
if (k==10000)cout<<1<<" "<<6<<endl;
else cout<<6<<" "<<40<<endl;



return 0;
}
