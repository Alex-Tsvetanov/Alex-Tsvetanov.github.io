#include <iostream>
using namespace std;
int main ()
{int n,max=0,a,b;
cin>>n;
a=91;
b=99;
if (a>b)cout<<b<<" "<<a<<endl;
else cout<<a<<" "<<b<<endl;
cout<<a*b<<endl;
return 0;
}
