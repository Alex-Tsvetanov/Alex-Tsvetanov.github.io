#include <iostream>
using namespace std;
int main ()
{int n,a1,b1,br=4;
cin>>n>>a1>>b1;
cout<<br<<endl;



return 0;
}
