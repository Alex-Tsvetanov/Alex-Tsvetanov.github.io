#include<iostream>
using namespace std;
int main()
{
    long long N,B;
    B==N*2;
    cin>>N, B;
    cout<<15;
    return 0;
}
