#include<iostream>
using namespace std;
int main()
{
    long long N, X, Y, Z ;
    cin>>N;
    X,Y<N;
    X*Y==Z;
    Z==12021
    cout<<Z;
    return 0;
}
