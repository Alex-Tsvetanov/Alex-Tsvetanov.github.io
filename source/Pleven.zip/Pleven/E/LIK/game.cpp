#include<iostream>
using namespace std;
int main()
{
    long long M, K, A,i;
    cin>>M, K;

    for (i++)
    {
     cin>>A;
       if(A==K)
       {
          cout<<A;
       }
       if(A-1=K)
       {
           cout<<A-1;
       }
       if(A+1==K)
       {
           cout<<A+1;
       }
    }



    return 0;
}
