#include<iostream>
using namespace std;
int main ()
{
    int n,a,b,br=0,maxbr=0,p,j,c,d,i;
    cin>>n>>a>>b;
    for (i=1;i<=n;i++)
        for(j=1;j<=n;j++)

    return 0;
}
