#include<iostream>
using namespace std;
int main ()
{
    int m,k,s,l,a;
    cin>>k>>a;
    for(l=1;l<=200;l++)
        cin>>a;
    s+=a;
    if(a%2==0)s+=a;
    if(l=200;)(cout<<j<<s<<endl;break)
    if(s>=a)(cout<<j<<s<<endl;break)
    return 0;
}
