#include<iostream>
using namespace std;
int main ()
{
    int n,l,j,n,s,k=0,y,p=0,i;
    cin>>n;
    for(l=n;l>=1;l--)
    {
        for(j=i;j<=n;j--)
        {
            s=l*j
            if(s==9009)cout<<"YES"<<endl;
            k=a;
            cout<<k<<endl;
            while
        }
    }
    return 0;
}
