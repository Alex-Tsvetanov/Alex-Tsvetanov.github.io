#include<iostream>
using namespace std;
int main()
{
  long long N, a,b,c;
  cin>>N;

  hil=c/1000-c%1000;
  sto=c/100-c%100;
  des=c/10-c%10;
  ed=c%10;
  hil=ed;
  des=sto;

  cout<<c<<endl;

    return 0;
}

