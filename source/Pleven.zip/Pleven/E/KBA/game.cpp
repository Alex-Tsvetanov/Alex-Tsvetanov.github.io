#include<iostream>
using namespace std;
int main()

{
    long  long sum1, sum2, br1, br2, num1, num2, num3, num4, num5, num6, num7;
    cin>>br1>>br2;
    cin>>num1;
    cin>>num2;
    cin>>num3;
    cin>>num4;
    cin>>num5;
    cin>>num6;
    cin>>num7;
    for (int i=1; i<=10; i++)
        if(num1,num2,num3,num4,num5,num6%2==0)
    {
        sum1=num3+num4+num6+num7;
        sum2=num6;
    }
    cout<<sum1<<endl;
    cout<<sum2<<endl;
return 0;
}
