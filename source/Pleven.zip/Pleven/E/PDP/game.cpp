#include<iostream>
using namespace std;
int main ()
{
   long long s, t, m, k, br1, a;
   cin>>s>>t;
   m=0;
   k=0;
   br1=0;
   cin>>s;
   t=1;
   while(a<=t and br1<200)
   {
       cin>>m;
       m=m+s;
       br1++;
       if(t<s)
       {
           if(s-t<t)
           {

           }
       }
   }
    return 0;
}
