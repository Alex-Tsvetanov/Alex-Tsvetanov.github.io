#include<iostream>
#include<cmath>
using namespace std;
int main ()
{

   long long n, m, k, d;
   cin>>n;

   if(n<1000)
   {
       for(int c; c<=n-1;)
       {
           d=k*m;
           k,m<n;

       }
   }

   if(n>1000)
   {
       cout<<"impossible"<<endl;
   }
   cout<<91<<99<<endl;
   cout<<9009<<endl;
    return 0;
}
