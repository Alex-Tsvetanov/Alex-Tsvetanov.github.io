#include<iostream>
using namespace std;
int main()
{
    long long n,a,b;
    cin>>n;
    b=n-1;
    while(a*b==)
    {

    }
    return 0;
}
