#include <iostream>
#include <cmath>
using namespace std;

int main()
{
int a,n,m;
cin>>a;
cin>>n>>m;
if(n<1||n>1000)
{
    cout<<"Nevalidno n";
    return 0;
}
if(m<1||m>10^12)
{
    cout<<"Nevalidno m";
    return 0;
}
}
