#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;



int ql,xr,qr,xl,qll,xrr,qrr,xll,a,b;



bool fff(int a, int b ){
    if(a<b)
        return true;
    else
        return false;
}

int main()
{
int i,n;
    for(i=1;i<=3;i++){

    }


cout<5;
    return 0;
}
