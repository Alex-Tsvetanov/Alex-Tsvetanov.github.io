#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
int a;
cin>>a;
cout<<a<<endl;
return 0;
}
