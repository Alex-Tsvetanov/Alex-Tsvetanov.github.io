#include<bits/stdc++.h>
using namespace std;
int a[720][30];
int rez[50];
int main()
{
for(i=0;i<=720;i++)
{
    for(j=1;j<=30;j++)
    {
        cin>>a[i][j];

    }
}

return 0;
}
