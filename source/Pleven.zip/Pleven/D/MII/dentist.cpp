#include <iostream>
using namespace std;

int a[100001],a[100001],k,brc;

int main (){
int i;





 return 0;
}
