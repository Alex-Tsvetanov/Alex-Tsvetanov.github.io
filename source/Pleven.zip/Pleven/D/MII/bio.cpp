#include <iostream>
using namespace std;

int main (){

cout<<21252<<endl;






 return 0;
}
