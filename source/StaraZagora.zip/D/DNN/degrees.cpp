#include <iostream>
#include <string.h>
using namespace std;

int main()
{
    
	return 0;
}