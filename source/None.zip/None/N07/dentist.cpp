#include<iostream>
using namespace std;
int main (){
       long long pristigane[720] , vreme[720];
       //720 minuti obshto;
return 0;
}
