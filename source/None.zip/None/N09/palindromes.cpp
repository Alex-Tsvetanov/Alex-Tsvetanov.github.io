#include <iostream>
using namespace std;
int main(){
    int n,i1,i2,c[6],brCif;
    long long palindrome,palProv,testCif;
    cin>>n;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){

        }
    }
}
