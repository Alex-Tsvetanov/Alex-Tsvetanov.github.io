#include <iostream>

using namespace std;
int stepen(int w) {
    int br=0;
    while (w!=0) {w/=2; br++;}
        return br;
}
int main () {
    string q;
    cin>>q;
    for (int i=0 ; i<q.size() ; i++) {

    }
		return 0;
}
//SAMO NE ZNAM KAK DA OTDELQ CHISLATA EDNO OT DRUGO. INACHE SHTESHE DA E LESNO//
