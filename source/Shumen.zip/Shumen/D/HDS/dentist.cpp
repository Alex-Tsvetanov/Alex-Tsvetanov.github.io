#include <iostream>
using namespace std;
int main()
{
int q,w,e=-1,r;
while (cin>>q>>w) if (q>e) {e=q; r=w;}
cout<<r<<endl;
    return 0;
}
//ZNAM CHE TOVA NE E VSICHKO,NO NE ZNAM KAK DA SE NAPRAVI AKO SE PRIPOKRIVAT VREMENATA//
//NADQVAM SE CHE TOVA SHTE DADE NQKAKVI TOCHKI//
