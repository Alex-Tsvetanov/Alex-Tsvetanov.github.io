#include <iostream>

using namespace std;
int main()
{
    int m1,m2,n=0,sum=0,sum1=0;
    while(cin>>m1>>m2)
    {
        n++;
        sum1+=m1+m2;

    }
cout<<sum1<<endl;
    return 0;
}
