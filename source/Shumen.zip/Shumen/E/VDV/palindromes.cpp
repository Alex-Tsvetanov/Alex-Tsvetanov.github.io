#include<iostream>
using namespace std;
int palindromes(int n)
{ int ch1=n-1;
  int ch2=n-1;
  int p=ch1*ch2;
}
int main()
{
int n;
cin>>n;

return 0;

}
