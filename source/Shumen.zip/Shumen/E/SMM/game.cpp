#include<iostream>
using namespace std;
int main()
{
int m,k;
cin>>m>>k;
int sum=1;
if(k%2==0)sum=sum+k;
cout<<sum<<endl;
return 0;
}
