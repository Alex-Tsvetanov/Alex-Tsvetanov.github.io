#include<iostream>
using namespace std;
int main()
{
int n;
for ()

return 0;
}