#include<iostream>
using namespace std;
int main()
{int m,k,br=0;
cin>>m;
for (int i=1;i<=m,;i++)
{
cin>>k;
}
for (int i=1;i<=m,;i++)
{
if (i%2)br++
cout<<br<<endl;

}




return 0;
}