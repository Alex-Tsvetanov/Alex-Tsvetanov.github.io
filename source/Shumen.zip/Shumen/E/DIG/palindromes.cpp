#include<iostream>
using namespace std;
int main()
{int n;
for (int i=0;i>n;i++)
{
cin>>n;
}
for (int i=0;i>n;i++)
{
cout<<i<<endl;
}


return 0;
}