#include <iostream>
using namespace std;
int main()
{
    cout<<6<<" "<<40;

  return 0;
}
