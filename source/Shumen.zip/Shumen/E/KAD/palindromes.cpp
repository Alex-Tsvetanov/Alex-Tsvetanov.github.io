#include <iostream>
using namespace std;
int main()
{
    int n,obn,pal,a,b,c;
    cin>>c;
    if(n==obn)
    {
        pal=obn;
    }
    if(a*b==n&&n<10000)
    {
        cout<<a<<" "<<b<<endl;
    }
    cout<<n<<endl;


  return 0;
}
